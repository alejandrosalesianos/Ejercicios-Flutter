class Const {
  static String movieDB = "https://api.themoviedb.org/3/person/popular";
  static String apiKey = "api_key=230fc17880d7d6f7d98b554ff0ba9294";
  static String language = "language=en-es";
}
